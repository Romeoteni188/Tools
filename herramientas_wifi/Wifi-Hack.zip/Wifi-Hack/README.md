<p align="center"><img src="https://user-images.githubusercontent.com/75953873/115979290-66309900-a55b-11eb-8259-4b125efc42bb.png"></p>

## Tested On:

### [✔] Kali Linux (Tool version 2.1)

![wifi-hack](https://user-images.githubusercontent.com/75953873/174921385-a512703d-a9d0-4ce5-837c-f7453401e140.png)


### [✔] Parrot OS (Tool version 2.0)

![wifi-hack-parrot](https://user-images.githubusercontent.com/75953873/192111809-3f18078e-80ed-4470-aba7-d9c9fbf6f024.png)


### [✔] Linux Mint (Tool version 1.0)

![wifi-hack-mint](https://user-images.githubusercontent.com/75953873/139563944-7eef6e72-05fd-4481-bcc4-bffa6edbb512.png)


### [✔] Ubuntu (Tool version 1.0)

![wifi-hack-ubuntu](https://user-images.githubusercontent.com/75953873/140593033-e8498792-2f3d-4651-8787-f882a43901b9.png)


### 🆕 Update 2.0
**`[+] Fake AP + Create Dictionary`**

**`[+] Cracking PIN WPS --> Wifite replaced for Bully`**

![fakeAP](https://user-images.githubusercontent.com/75953873/174706969-1ca06a64-e34c-4a99-9502-56291a2d188b.png)

<img src="https://user-images.githubusercontent.com/75953873/156779190-1c07faca-2e1c-453c-9c82-42396bf19acd.jpg" width="230" height="510">

![bully](https://user-images.githubusercontent.com/75953873/174921009-6221cb04-fe8a-47e4-b46a-78748bb6aac4.png)

</br>

### 🆕 Update 2.1

**`[+] Scan output in format CSV`**

![output](https://github.com/user-attachments/assets/65da59eb-73a3-408c-ab2a-dc1fcede0e07)

![outputCSV](https://github.com/user-attachments/assets/42bff460-f6b1-4298-b7fd-da347e6ff05e)

</br>

## Instalación / Installation

```
• git clone https://github.com/R3LI4NT/Wifi-Hack
• cd Wifi-Hack
• sudo bash requirements.sh
• python3 wifi-hack.py
```

</br>

<h1 align="center"></h1>

### Importante

**`ES:`** No me hago responsable del mal uso que se le pueda dar a esta herramienta, úselo para Pentesting o fines educativos.

**`EN:`**  I am not responsible for the misuse that may be given to this tool, use it for Pentesting or educational purposes.

#R3LI4NT

## El objetivo de está herramienta es automatizar los procesos de aircrack-ng.
